function[x,Cov]=fmin(a)
% Rosenbrock Function Test 
% a is in the form of a vector [x1,x2]
x0=a;
  options = optimset('PlotFcns',@optimplotfval,'TolFun',1e-9,'TolX',1e-9,'MaxIter',100000);
  [x,fval,exitflag,output,Cov] = fminsearchbnd(@Mini,x0,[],[],options,1);
  
   function z = Mini(x)
       z=(1-x(1)).^2 + 100*(x(2)-x(1).^2).^2;
   end
end

