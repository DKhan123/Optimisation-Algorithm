Optimisation Algorithm 2.0

------------------------------------------------------------------------------------------------------------------------------------------------------------
Latest Version available on Github https://github.com/DKhan123?tab=repositories

This document contains information on the MATLAB files in this folder and how to run the code. 
The programme is run from Optimisation_Algorithm_2_0

** IMPORTANT ** 
This code uses the nelder mead algorithm as implemented in the MATLAB code fminsearch and fminsearchbnd. However, to calculate covariances modifications needed to be made to both sets of code. The modified version of fminsearchbnd is available in this folder. For licencing reasons, the modified version of fminsearch cannot be provided. 
The modifications needed are as follows: 
0. To access the source code for fminsearch, type fminsearch into the matlab command window. Highlight fminsearch, right click and open selection. 
1. In the source code replace/add the following code at these lines. 

Line 1: Extracting simplex 
function [x,fval,exitflag,output,Simplex] = Fminsearch(funfcn,x,options,varargin)

Line 256: Setting the size of the initial simplex
usual_delta = 0.15;  

Lines 314-317: Transforming variables from fminsearchbnd to standard form
    for i = 1 : size(v,2)
    XTR=xtransform(v(:,i),varargin{:});
    XT(:,i)=reshape(XTR,varargin{:}.xsize);
    end    
    if max(abs(fv(1)-fv(two2np1))) <= max(tolf,10*eps(fv(1))) && ...
            max(max(abs(XT(:,two2np1)-XT(:,onesn)))) <= max(tolx,10*eps(max(XT(:,1))))
        break
    end

Line 451: Collating simplex data. Placed between end and output.message = msg;
Simplex={fval,two2np1,v,sigma,fv,varargin,funfcn};

Line 551: Function to transform parameters from fminsearchbnd (D’Errico, 2010)
function xtrans = xtransform(x,params)
xtrans = zeros(params.xsize);
k=1;
for i = 1:params.n
  switch params.BoundClass(i)
    case 1
      xtrans(i) = params.LB(i) + x(k).^2;
            k=k+1;
    case 2
      xtrans(i) = params.UB(i) - x(k).^2;
            k=k+1;
    case 3
        xtrans(i) = (sin(x(k))+1)/2;
      xtrans(i) = xtrans(i)*(params.UB(i) - params.LB(i)) + params.LB(i);
      xtrans(i) = max(params.LB(i),min(params.UB(i),xtrans(i)));
            k=k+1;
    case 4
           xtrans(i) = params.LB(i);
    case 0
      xtrans(i) = x(k);
            k=k+1;
  end
end

2. Save the modified file as Fminsearch.m 

** IMPORTANT **

------------------------------------------------------------------------------------------------------------------------------------------------------------
Default minimizer is meemum version 6.9.0
Other minimizers require modifications to allow txt files to be read properly. 
Files needed to run the minimizer should also be included:
E.g. for meemum: RunMeemum, Solution_Model, Param_Model 

RunMeemum should use Param_Model_New and Solution_Model_New as the data file names.

------------------------------------------------------------------------------------------------------------------------------------------------------------
The thermodynamic model should be stored in ThermoModel.dat with interaction Parameters in WijData.dat 

The file format is:
1. Name of endmember, Name of mineral the endmember belongs to, Mr, Name of properties as given in the output of the minimizer. Errors written as Property_er
2. Data 
3.... Repeat 2 

------------------------------------------------------------------------------------------------------------------------------------------------------------
Bulk Composition is stored in the BulkComp.dat file. 

The file format is:

Components
1. Name of the components
2. Mr of components
3. Cations 
4. end

Bulk Comp
1. Name of Bulk composition, Component amounts..., weight or mol%
end

------------------------------------------------------------------------------------------------------------------------------------------------------------
Data should be stored in consecutive files named Data1.dat, Data2.dat .... 
The file format is:

PT Conditions:
1. C, or K, for celcius or kelvin 
2. Temperature of experiment
3. GPa or bar for pressure
4. Pressure of experiment
5. End

6. Name of bulk composition, Properties of experiment, Errors % Names as given in either the thermo model file or the component names. Errors end in _er
7. Phase name, Properties, Errors  
8... Same as 7    
  
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
MATLAB 

The MATLAB files included are:

Optimisation_Algorithm_2_0: Main programme. 

Composition: Processes Data and calculates Wt% Errors - Requires modification for phases present in your experiments. 
ExpMassCorrection: Correction for improper mass balance in Composition.

GEM: Gibbs energy minimiser - Requires some modification if changing minimiser. 
ReadGEM: Reads results from GEM. If GEM is changed, this needs to be updated to properly read GEM results. 
jsystem: Runs GEM calculations. Slightly faster than in built MATLAB system command.

VarOutput: Contains termination criteria for the minimiser. 
fminsearchbnd: Processes parameters to be run in Minimum and calculates covariance matrix. 
Minimum: Calculates Residual.
UpdateModel: Updates thermodynamic model text files. Requires some modification if GEM is changed. 

CallSign: Determine Call sign ID needed for thermodynamic parameters. Requires modification based on the thermodynamic model file being used. 

SPD: Calculates nearest SemiPositiveDefinite Matrix

------------------------------------------------------------------------------------------------------------------------------------------------------------
Optional files:
fmin: Test function for covariance calculator. Uses Rosenbrock function. 
 
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------







  